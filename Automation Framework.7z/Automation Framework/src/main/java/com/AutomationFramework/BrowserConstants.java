package com.AutomationFramework;

public class BrowserConstants {
	public final static String FIREFOX="FIREFOX";
	public final static String CHROME="CHROME";
	public final static String IE="IE";
	public final static String EDGE="EDGE";
	

}
