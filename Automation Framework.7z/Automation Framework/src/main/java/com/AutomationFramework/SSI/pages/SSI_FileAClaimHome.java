package com.AutomationFramework.SSI.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SSI_FileAClaimHome {
	
	@FindBy(xpath="//input[@value='File A Claim']")
	private WebElement FileAClaimBtn;

}
