package com.AutomationFramework;

public class ApplicationStaticData {
	
	public final static String YesText="Yes";
	public final static String NoText="No";
	public final static String OtherText= "Other";
	public final static String blank= "";
	public final static String LoopsNJPrefixText = "LoopsNJ";
	public final static String NJPrefixText = "NJ";

}
